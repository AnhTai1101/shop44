<?php $this->layout = "views/frontend/layout.php"; ?>
<button id="thaydoi" class="btn btn-success">Name</button>
