<?php
    trait newsModel{
        public function list_news(){
            $conn = Connection::getInstance();
        }
    }
?>