<?php 
// ajax goi den file nay a e ?
	//start session
	session_start();
	//include file config.php
	include "config.php";
	//include file connection de ket noi csdl
	include "app/connection.php";
	//include file controller.php
	include "app/controller.php";
	//include file routing.php de dinh tuyen url
	include "app/routing.php";
 ?>