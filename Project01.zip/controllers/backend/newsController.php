<?php
    include "models/backend/newsModel.php";
    class newsController extends Controller{
        public function index(){

        }
    }
?>