<?php
    $host = "localhost"; // localhost cho trang web
    $db = "shop"; // database name
    $user = "root";
    $password = "";
?>